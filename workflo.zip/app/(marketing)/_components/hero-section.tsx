import Link from "next/link";
import { ArrowRight, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import { TextEffect } from "@/components/motion-primitives/text-effect";
import { AnimatedGroup } from "@/components/motion-primitives/animated-group";
import { HeroHeader } from "@/app/(marketing)/_components/header";
import BackgroundImage from "@/public/night-background.webp";
import HeroLight from "@/public/hero-light.png";
import HeroDark from "@/public/hero-dark.png";
import NovaFlow from "@/public/companies/NovaFlow.svg";
import OrbitIQ from "@/public/companies/OrbitIQ.svg";
import Lumora from "@/public/companies/Lumora.svg";
import VertexAI from "@/public/companies/VertexAI.svg";
import Nexora from "@/public/companies/Nexora.svg";
import CloudNest from "@/public/companies/CloudNest.svg";
import Synapse from "@/public/companies/Synapse.svg";
import PrismStack from "@/public/companies/PrismStack.svg";
import { CompanyLogo } from "../../../components/ui/company-logo";

const transitionVariants = {
  item: {
    hidden: {
      opacity: 0,
      filter: "blur(12px)",
      y: 12,
    },
    visible: {
      opacity: 1,
      filter: "blur(0px)",
      y: 0,
      transition: {
        type: "spring" as const,
        bounce: 0.3,
        duration: 1.5,
      },
    },
  },
};

const companies = [
  { name: "NovaFlow", logo: NovaFlow },
  { name: "OrbitIQ", logo: OrbitIQ },
  { name: "Lumora", logo: Lumora },
  { name: "VertexAI", logo: VertexAI },
  { name: "Nexora", logo: Nexora },
  { name: "CloudNest", logo: CloudNest },
  { name: "Synapse", logo: Synapse },
  { name: "PrismStack", logo: PrismStack },
];

export default function HeroSection() {
  return (
    <>
      <HeroHeader />
      <main className="overflow-hidden">
        <div
          aria-hidden
          className="absolute inset-0 isolate hidden opacity-65 contain-strict lg:block"
        >
          <div className="w-140 h-320 -translate-y-87.5 absolute left-0 top-0 -rotate-45 rounded-full bg-[radial-gradient(68.54%_68.72%_at_55.02%_31.46%,hsla(0,0%,85%,.08)_0,hsla(0,0%,55%,.02)_50%,hsla(0,0%,45%,0)_80%)]" />
          <div className="h-320 absolute left-0 top-0 w-60 -rotate-45 rounded-full bg-[radial-gradient(50%_50%_at_50%_50%,hsla(0,0%,85%,.06)_0,hsla(0,0%,45%,.02)_80%,transparent_100%)] [translate:5%_-50%]" />
          <div className="h-320 -translate-y-87.5 absolute left-0 top-0 w-60 -rotate-45 bg-[radial-gradient(50%_50%_at_50%_50%,hsla(0,0%,85%,.04)_0,hsla(0,0%,45%,.02)_80%,transparent_100%)]" />
        </div>
        <section>
          <div className="relative pt-24 md:pt-36">
            <AnimatedGroup
              variants={{
                container: {
                  visible: {
                    transition: {
                      delayChildren: 1,
                    },
                  },
                },
                item: {
                  hidden: {
                    opacity: 0,
                    y: 20,
                  },
                  visible: {
                    opacity: 1,
                    y: 0,
                    transition: {
                      type: "spring",
                      bounce: 0.3,
                      duration: 2,
                    },
                  },
                },
              }}
              className="mask-y-from-35% mask-y-to-90% absolute inset-0 top-56 lg:top-12"
            >
              <Image
                src={BackgroundImage}
                alt="background"
                className="hidden size-full mix-blend-overlay dark:block"
                width="3276"
                height="4095"
                priority
              />
            </AnimatedGroup>

            <div
              aria-hidden
              className="absolute inset-0 -z-10 size-full [background:radial-gradient(125%_125%_at_50%_100%,transparent_0%,var(--color-background)_75%)]"
            />

            <div className="mx-auto max-w-7xl px-6">
              <div className="text-center sm:mx-auto lg:mr-auto lg:mt-0">
                <AnimatedGroup variants={transitionVariants}>
                  <Link
                    href="#link"
                    className="hover:bg-background dark:hover:border-t-border bg-muted group mx-auto flex w-fit items-center gap-4 rounded-full border p-1 pl-4 shadow-md shadow-zinc-950/5 transition-colors duration-300 dark:border-t-white/5 dark:shadow-zinc-950"
                  >
                    <span className="text-foreground text-sm">
                      Meet the next generation of team collaboration
                    </span>
                    <span className="dark:border-background block h-4 w-0.5 border-l bg-white dark:bg-zinc-700"></span>

                    <div className="bg-background group-hover:bg-muted size-6 overflow-hidden rounded-full duration-500">
                      <div className="flex w-12 -translate-x-1/2 duration-500 ease-in-out group-hover:translate-x-0">
                        <span className="flex size-6">
                          <ArrowRight className="m-auto size-3" />
                        </span>
                        <span className="flex size-6">
                          <ArrowRight className="m-auto size-3" />
                        </span>
                      </div>
                    </div>
                  </Link>
                </AnimatedGroup>

                <TextEffect
                  preset="fade-in-blur"
                  speedSegment={0.3}
                  as="h1"
                  className="mx-auto mt-8 max-w-4xl text-balance text-5xl max-md:font-semibold md:text-7xl lg:mt-16 xl:text-[5.25rem]"
                >
                  The smarter workspace for AI-driven Team collaboration
                </TextEffect>
                <TextEffect
                  per="line"
                  preset="fade-in-blur"
                  speedSegment={0.3}
                  delay={0.5}
                  as="p"
                  className="mx-auto mt-8 max-w-2xl text-balance text-lg"
                >
                  Workflo brings conversations, projects, and AI together in one
                  workspace—keeping every team connected, organized, and moving
                  faster.
                </TextEffect>

                <AnimatedGroup
                  variants={{
                    container: {
                      visible: {
                        transition: {
                          staggerChildren: 0.05,
                          delayChildren: 0.75,
                        },
                      },
                    },
                    ...transitionVariants,
                  }}
                  className="mt-12 flex flex-col items-center justify-center gap-5 md:flex-row"
                >
                  <div
                    key={1}
                    className="bg-foreground/10 rounded-[calc(var(--radius-xl)+0.125rem)] border p-0.5"
                  >
                    <Button
                      asChild
                      size="lg"
                      className="rounded-xl px-5 text-base"
                    >
                      <Link href="#link">
                        <span className="text-nowrap">Get Started</span>
                      </Link>
                    </Button>
                  </div>
                  <Button
                    key={2}
                    asChild
                    size="lg"
                    variant="secondary"
                    className="h-10.5 rounded-xl px-5"
                  >
                    <Link href="#link">
                      <span className="text-nowrap">Request a demo</span>
                    </Link>
                  </Button>
                </AnimatedGroup>
              </div>
            </div>

            <AnimatedGroup
              variants={{
                container: {
                  visible: {
                    transition: {
                      staggerChildren: 0.05,
                      delayChildren: 0.75,
                    },
                  },
                },
                ...transitionVariants,
              }}
            >
              <div className="mask-b-from-55% relative -mr-56 mt-8 overflow-hidden px-2 sm:mr-0 sm:mt-12 md:mt-20">
                <div className="inset-shadow-2xs ring-background dark:inset-shadow-white/20 bg-background relative mx-auto max-w-6xl overflow-hidden rounded-2xl border p-4 shadow-lg shadow-zinc-950/15 ring-1">
                  <Image
                    className="bg-background aspect-15/8 relative hidden rounded-2xl dark:block object-contain object-center"
                    src={HeroDark}
                    alt="app screen"
                    width="2700"
                    height="1440"
                    priority
                  />
                  <Image
                    className="z-2 border-border/25 aspect-15/8 relative rounded-2xl border dark:hidden object-contain object-center"
                    src={HeroLight}
                    alt="app screen"
                    width="2700"
                    height="1440"
                    priority
                  />
                </div>
              </div>
            </AnimatedGroup>
          </div>
        </section>
        <section className="bg-background pb-16 pt-16 md:pb-32">
          <div className="group relative m-auto max-w-5xl px-6">
            <div className="mb-16 text-center">
              <Link
                href="/"
                className="inline-flex items-center gap-1 text-sm font-medium uppercase tracking-[0.25em] text-muted-foreground transition-opacity hover:opacity-75 dark:text-white/80"
              >
                <span>Trusted by innovative teams worldwide</span>

                <ChevronRight className="ml-1 inline-block size-3" />
              </Link>
            </div>

            <div className="relative left-1/2 mt-16 w-screen -translate-x-1/2 transition-all duration-500 group-hover:opacity-50">
              <div className="relative overflow-hidden">
                <div className="absolute inset-y-0 left-0 z-10 w-24 bg-linear-to-r from-background to-transparent" />
                <div className="absolute inset-y-0 right-0 z-10 w-24 bg-linear-to-l from-background to-transparent" />
                <div className="flex w-max items-center animate-marquee gap-24">
                  {[...companies, ...companies].map((company, index) => (
                    <CompanyLogo
                      key={index}
                      name={company.name}
                      logo={company.logo}
                      priority={index === 0}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
